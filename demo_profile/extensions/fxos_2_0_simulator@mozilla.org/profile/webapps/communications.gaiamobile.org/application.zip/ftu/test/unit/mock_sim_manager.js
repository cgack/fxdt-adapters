'use strict';

var MockSimManager = {

  handleCardState: function() {},
  checkSIMButton: function() {},
  available: function() {}

};
