/* exported MockTimeManager */
'use strict';

var MockTimeManager = {
  init: function () {},
  set: function (date) {}
};
