'use strict';

var Mockutils = {
  overlay: {
    show: function() {},
    hide: function() {}
  }
};
