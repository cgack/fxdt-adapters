/* exported MockExtServices */
'use strict';

var MockExtServices = {
  startLink: function() {},
  importFB: function() {},
  importGmail: function() {},
  importLive: function() {},
  match: function() {},
  showDuplicateContacts: function() {},
  showProfile: function() {},
  wallPost: function() {},
  sendPrivateMsg: function() {},
  initEventHandlers: function() {}
};
