'use strict';
/* exported MockActivities */

var MockActivities = {
  currentlyHandling: false,
  activityName: 'view',
  postPickSuccess: function(data) {
  }
};
