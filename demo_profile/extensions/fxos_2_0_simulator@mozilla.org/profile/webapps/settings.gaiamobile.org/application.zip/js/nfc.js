/* Copyright © 2013, Deutsche Telekom, Inc. */



// handle Nfc settings
navigator.mozL10n.once(function nfcSettings() {
  // Check if NFC is available on platform, and update UI
  if (document.getElementById('nfc-settings')) {
    document.getElementById('nfc-settings').hidden = !getNfc();
  }
});

