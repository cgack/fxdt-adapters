/* FIXME */

function foo(bar) {
  return bar +1;
}

alert('hello');